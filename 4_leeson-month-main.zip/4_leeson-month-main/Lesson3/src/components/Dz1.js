import React from 'react';


const Dz1 = ({name, age}) => {
    return (
        <div>
            name: {name}
            age: {age}
        </div>
    );
};

export default Dz1;