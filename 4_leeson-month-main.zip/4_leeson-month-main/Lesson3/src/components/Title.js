import React from 'react';


const Title = ({title}) => {
    // console.log(props,'props');
    // const {title} = props
    return (
        <div style={{color: 'red'}}>
            {
                title
            }
        </div>
    );
};

export default Title;