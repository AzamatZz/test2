import React from 'react';
import Title from "./Title";

const Footer = () => {
    return (
        <div>
            <Title title={"Footer"} name={"Header"}/>
        </div>
    );
};

export default Footer;