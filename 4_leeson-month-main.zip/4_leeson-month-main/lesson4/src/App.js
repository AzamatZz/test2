import './App.css';
import MainPage from './pages/MainPage';
import React from 'react';
import TodoPage from './pages/TodoPage';


function App() {
    return (
        <div className="App">
            {/*<MainPage/>*/}
            <TodoPage/>
        </div>
    );
}


export default App;
