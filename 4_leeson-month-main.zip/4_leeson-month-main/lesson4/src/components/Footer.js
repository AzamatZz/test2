import React from 'react';
import Title from './Title';


const Footer = () => {
    const sum = () => {

    }
    return (
        <>
            <div>
                <Title title={'Footer'}/>
                <div>
                    <span></span>
                </div>
            </div>
            <h1>
                ertherth
            </h1>
        </>
    );
};

export default Footer;

const sum = (a,b) => {
    return a+b
}

console.log(sum(10,9));