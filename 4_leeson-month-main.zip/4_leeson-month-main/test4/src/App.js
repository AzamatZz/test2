import React from 'react';
import MainPage from "./pages/mainpage/MainPage";

const App = () => {
    return (
        <>
            <MainPage/>
        </>
    );
};

export default App;